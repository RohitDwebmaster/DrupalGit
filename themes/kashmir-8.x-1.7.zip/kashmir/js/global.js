/**
 * @file
 * Globaly required script.
 */

(function iife() {}());
